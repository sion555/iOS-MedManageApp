const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Prescription = sequelize.define('Prescription', {
    prescriptionID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    userID: {
      type: DataTypes.STRING(50),
      allowNull: false,
      references: {
        model: 'user',
        key: 'userID',
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
    },
    hospitalName: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    prescriptionStartDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    prescriptionEndDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  }, {
    timestamps: true,
    paranoid: true,
    modelName: 'Prescription',
    tableName: 'prescription',
  });

  Prescription.associate = (models) => {
    Prescription.belongsTo(models.User, { foreignKey: 'userID', targetKey: 'userID' });
    Prescription.hasMany(models.Receipt, { foreignKey: 'prescriptionID', sourceKey: 'prescriptionID' });
    Prescription.hasMany(models.Instruction, { foreignKey: 'prescriptionID', sourceKey: 'prescriptionID' });
    Prescription.belongsToMany(models.Pill, { through: models.Instruction, foreignKey: 'prescriptionID', otherKey: 'pillID' });
  };

  return Prescription;
};
