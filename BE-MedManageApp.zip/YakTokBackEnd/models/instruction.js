const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Instruction = sequelize.define('Instruction', {
    instructionID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    prescriptionID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'prescription',
        key: 'prescriptionID',
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
    },
    pillID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pill',
        key: 'pillID',
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
    },
    instruction: {
      type: DataTypes.TEXT,
      allowNull: true,
    }
  }, {
    timestamps: true,
    paranoid: true,
    modelName: 'Instruction',
    tableName: 'instruction',
  });

  Instruction.associate = (models) => {
    Instruction.belongsTo(models.Prescription, { foreignKey: 'prescriptionID', targetKey: 'prescriptionID' });
    Instruction.belongsTo(models.Pill, { foreignKey: 'pillID', targetKey: 'pillID' });
  };

  return Instruction;
};
