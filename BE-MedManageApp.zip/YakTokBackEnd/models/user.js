const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    userID: {
      type: DataTypes.STRING(50),
      allowNull: false,
      primaryKey: true,
    },
    userName: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING(200),
      allowNull: false,
    },
  }, {
    timestamps: true,
    paranoid: true,
    modelName: 'User',
    tableName: 'user',
  });

  User.associate = (models) => {
    User.hasMany(models.Prescription, { foreignKey: 'userID', sourceKey: 'userID' });
    User.hasMany(models.Receipt, { foreignKey: 'userID', sourceKey: 'userID' });
    User.hasMany(models.Pill, { foreignKey: 'userID', sourceKey: 'userID' }); // User와 Pill의 관계 추가
  };

  return User;
};
