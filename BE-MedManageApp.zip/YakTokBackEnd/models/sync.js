const { sequelize } = require('./index');

const sync = async () => {
  try {
    await sequelize.sync({ force: true });
    console.log('Database synchronized');
  } catch (err) {
    console.error('Error synchronizing database:', err);
  }
};

module.exports = sync;
