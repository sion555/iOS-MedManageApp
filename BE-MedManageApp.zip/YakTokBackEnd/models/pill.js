const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Pill = sequelize.define('Pill', {
    pillID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    pillName: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    pillImage: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    pillDescription: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    pillType: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    storageMethod: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    medicineEffect: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    userID: {
      type: DataTypes.STRING(50),
      allowNull: false,
      references: {
        model: 'user',
        key: 'userID',
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
    },
    prescriptionID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'prescription',
        key: 'prescriptionID',
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
    },
    doseTime: {
      type: DataTypes.STRING(50),
      allowNull: true,
    }
  }, {
    timestamps: true,
    paranoid: true,
    modelName: 'Pill',
    tableName: 'pill',
  });

  Pill.associate = (models) => {
    Pill.belongsTo(models.Prescription, { foreignKey: 'prescriptionID', targetKey: 'prescriptionID' });
    Pill.belongsTo(models.User, { foreignKey: 'userID', targetKey: 'userID' });
    Pill.hasMany(models.Instruction, { foreignKey: 'pillID', sourceKey: 'pillID' });
    Pill.belongsToMany(models.Prescription, { through: models.Instruction, foreignKey: 'pillID', otherKey: 'prescriptionID' });
  };

  return Pill;
};
