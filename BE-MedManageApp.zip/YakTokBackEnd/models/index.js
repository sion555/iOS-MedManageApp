// const Sequelize = require('sequelize');
// const process = require('process');
// const env = process.env.NODE_ENV || 'development';
// const config = require('../config/config.json')[env];

// const db = {};

// let sequelize = new Sequelize(
//   config.database,
//   config.username,
//   config.password,
//   config
// );

// const User = require('./user')(sequelize);
// const Pill = require('./pill')(sequelize);
// const Prescription = require('./prescription')(sequelize);
// const Receipt = require('./receipt')(sequelize);
// const Instruction = require('./instruction')(sequelize);

// db.User = User;
// db.Pill = Pill;
// db.Prescription = Prescription;
// db.Receipt = Receipt;
// db.Instruction = Instruction;

// Object.keys(db).forEach(modelName => {
//   if (db[modelName].associate) {
//     db[modelName].associate(db);
//   }
// });

// db.sequelize = sequelize;
// db.Sequelize = Sequelize;

// module.exports = db;


const Sequelize = require('sequelize');
const env = process.env.NODE_ENV || 'development';
const config = require('../config/config.json')[env];

const db = {};

let sequelize = new Sequelize(
  config.database,
  config.username,
  config.password,
  config
);

const User = require('./user')(sequelize);
const Pill = require('./pill')(sequelize);
const Prescription = require('./prescription')(sequelize);
const Receipt = require('./receipt')(sequelize);
const Instruction = require('./instruction')(sequelize);

db.User = User;
db.Pill = Pill;
db.Prescription = Prescription;
db.Receipt = Receipt;
db.Instruction = Instruction;

User.associate(db);
Pill.associate(db);
Prescription.associate(db);
Receipt.associate(db);
Instruction.associate(db);

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
