const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Receipt = sequelize.define('Receipt', {
    receiptID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    prescriptionID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'prescription',
        key: 'prescriptionID',
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
    },
    userID: {
      type: DataTypes.STRING(50),
      allowNull: false,
      references: {
        model: 'user',
        key: 'userID',
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
    },
    receiptNumber: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    totalPillExpense: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    personalExpense: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    insuranceExpense: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    nonCoveredExpense: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    totalPayment: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    cardPayment: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    cashPayment: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    pharmacyName: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    hospitalName: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
  }, {
    timestamps: true,
    paranoid: true,
    modelName: 'Receipt',
    tableName: 'receipt',
  });

  Receipt.associate = (models) => {
    Receipt.belongsTo(models.Prescription, { foreignKey: 'prescriptionID', targetKey: 'prescriptionID' });
    Receipt.belongsTo(models.User, { foreignKey: 'userID', targetKey: 'userID' });
  };

  return Receipt;
};
