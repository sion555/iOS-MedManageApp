const express = require('express');
const { Receipt } = require('../models/index');
const router = express.Router();
const isAuth = require('./authorization');
const jwt = require('jsonwebtoken');
const secret = process.env.JWT_SECRET;

// 특정 사용자의 영수증 정보 조회 경로
router.get('/', isAuth, async (req, res) => {
    const userID = req.userID;

    try {
        const receipts = await Receipt.findAll({
            where: { userID },
            attributes: ['receiptID', 'prescriptionID', 'receiptNumber', 'totalPillExpense', 'personalExpense', 'insuranceExpense', 'nonCoveredExpense', 'totalPayment', 'pharmacyName', 'hospitalName']
        });

        if (!receipts || receipts.length === 0) {
            return res.status(404).json({ success: false, receipts: [], message: '영수증 정보를 찾을 수 없습니다.' });
        }

        res.status(200).json({ success: true, receipts, message: '영수증 정보 조회 성공' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, receipts: [], message: '영수증 정보 조회 실패', details: error.message });
    }
});


// prescriptionID를 기반으로 영수증 정보를 가져오는 경로
router.get('/prescription/:prescriptionID', isAuth, async (req, res) => {
    const { prescriptionID } = req.params;

    if (!prescriptionID) {
        return res.status(400).json({ success: false, receipts: [], message: 'prescriptionID가 필요합니다.' });
    }

    try {
        const receipts = await Receipt.findAll({
            where: { prescriptionID },
            attributes: ['receiptID', 'prescriptionID', 'receiptNumber', 'totalPillExpense', 'personalExpense', 'insuranceExpense', 'nonCoveredExpense', 'totalPayment', 'pharmacyName', 'hospitalName']
        });

        if (!receipts || receipts.length === 0) {
            return res.status(404).json({ success: false, receipts: [], message: '영수증 정보를 찾을 수 없습니다.' });
        }

        res.status(200).json({ success: true, receipts, message: '영수증 정보 조회 성공' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, receipts: [], message: '영수증 정보 조회 실패', details: error.message });
    }
});

// 영수증 정보 추가 경로
router.post('/', isAuth, async (req, res) => {
    const { prescriptionID, userID, receiptNumber, totalPillExpense, personalExpense, insuranceExpense, nonCoveredExpense, totalPayment, pharmacyName, hospitalName } = req.body;

    if (!prescriptionID || !userID) {
        return res.status(400).json({ success: false, message: '필수 정보가 누락되었습니다.' });
    }

    try {
        const newReceipt = await Receipt.create({
            prescriptionID,
            userID,
            receiptNumber,
            totalPillExpense,
            personalExpense,
            insuranceExpense,
            nonCoveredExpense,
            totalPayment,
            pharmacyName,
            hospitalName
        });

        res.status(201).json({ success: true, receipt: newReceipt, message: '영수증 정보 추가 성공' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: '영수증 정보 추가 실패', details: error.message });
    }
});

// 특정 영수증 정보를 수정하는 경로
router.patch('/:receiptID', isAuth, async (req, res) => {
    const { receiptID } = req.params;
    const updateData = req.body;
    const userID = req.userID;

    if (!receiptID) {
        return res.status(400).json({ success: false, message: 'receiptID가 필요합니다.' });
    }

    try {
        const receipt = await Receipt.findOne({ where: { receiptID, userID } });

        if (!receipt) {
            return res.status(404).json({ success: false, message: '영수증 정보를 찾을 수 없습니다.' });
        }

        await receipt.update(updateData);
        res.status(200).json({ success: true, receipt, message: '영수증 정보 수정 성공' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: '영수증 정보 수정 실패', details: error.message });
    }
});

module.exports = router;
