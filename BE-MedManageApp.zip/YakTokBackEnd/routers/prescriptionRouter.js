const express = require('express');
const { Prescription, Receipt, Pill, Instruction } = require('../models/index');
const router = express.Router();
const { Sequelize } = require('sequelize');
const env = process.env.NODE_ENV || 'development';
const config = require('../config/config.json')[env];
const sequelize = new Sequelize(
  config.database,
  config.username,
  config.password,
  config
);
const isAuth = require('./authorization');

// 특정 처방과 관련된 모든 정보를 삭제하는 경로
router.delete('/:prescriptionID', isAuth, async (req, res) => {
    const { prescriptionID } = req.params;
    const userID = req.userID;

    if (!prescriptionID) {
        return res.status(400).json({ success: false, message: 'prescriptionID가 필요합니다.' });
    }

    let transaction;
    try {
        transaction = await sequelize.transaction();

        // 먼저 Instruction 삭제
        await Instruction.destroy({
            where: { prescriptionID },
            include: [{ model: Prescription, where: { userID } }],
            transaction
        });

        // 그 다음 Pill 삭제
        await Pill.destroy({
            where: { prescriptionID },
            include: [{ model: Prescription, where: { userID } }],
            transaction
        });

        // 마지막으로 Receipt와 Prescription 삭제
        await Receipt.destroy({
            where: { prescriptionID },
            include: [{ model: Prescription, where: { userID } }],
            transaction
        });
        await Prescription.destroy({
            where: { prescriptionID, userID },
            transaction
        });

        await transaction.commit();
        res.status(200).json({ success: true, message: '처방 및 관련 정보 삭제 성공' });
    } catch (error) {
        if (transaction) await transaction.rollback();
        console.error(error);
        res.status(500).json({ success: false, message: '처방 및 관련 정보 삭제 실패', details: error.message });
    }
});

// 특정 사용자의 처방 정보 조회
router.get('/', isAuth, async (req, res) => {
    const userID = req.userID;

    try {
        const prescriptions = await Prescription.findAll({
            where: { userID },
            include: [
                {
                    model: Pill,
                    attributes: ['pillID', 'pillName', 'pillImage', 'pillDescription', 'pillType', 'storageMethod', 'medicineEffect', 'prescriptionID', 'doseTime']
                },
                {
                    model: Receipt,
                    attributes: ['receiptID', 'prescriptionID', 'receiptNumber', 'totalPillExpense', 'personalExpense', 'insuranceExpense', 'nonCoveredExpense', 'totalPayment', 'pharmacyName', 'hospitalName']
                }
            ]
        });

        if (!prescriptions || prescriptions.length === 0) {
            return res.status(404).json({ success: false, prescriptions: [], message: '처방전 정보를 찾을 수 없습니다.' });
        }

        res.status(200).json({ success: true, prescriptions, message: '처방전 정보 조회 성공' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, prescriptions: [], message: '처방전 정보 조회 실패', details: error.message });
    }
});


// 특정 처방 정보 조회
router.get('/:prescriptionID', isAuth, async (req, res) => {
    const { prescriptionID } = req.params;
    const userID = req.userID;

    try {
        const result = await Prescription.findOne({
            where: {
                prescriptionID,
                userID
            },
            include: [
                {
                    model: Receipt,
                    attributes: ['receiptID', 'prescriptionID', 'receiptNumber', 'totalPillExpense', 'personalExpense', 'insuranceExpense', 'nonCoveredExpense', 'totalPayment', 'pharmacyName', 'hospitalName']
                },
                {
                    model: Instruction,
                    include: [
                        {
                            model: Pill,
                            attributes: ['pillID', 'pillName', 'pillImage', 'pillDescription', 'pillType', 'storageMethod', 'medicineEffect', 'doseTime']
                        }
                    ]
                }
            ]
        });

        if (!result) {
            return res.status(404).json({ success: false, prescription: [], message: '처방 정보를 찾을 수 없습니다.' });
        }

        const formattedResult = {
            prescriptionID: result.prescriptionID,
            userID: result.userID,
            hospitalName: result.hospitalName,
            prescriptionStartDate: result.prescriptionStartDate,
            prescriptionEndDate: result.prescriptionEndDate,
            createdAt: result.createdAt,
            updatedAt: result.updatedAt,
            deletedAt: result.deletedAt,
            Receipts: result.Receipts.map(receipt => ({
                receiptID: receipt.receiptID,
                prescriptionID: receipt.prescriptionID,
                receiptNumber: receipt.receiptNumber,
                totalPillExpense: receipt.totalPillExpense,
                personalExpense: receipt.personalExpense,
                insuranceExpense: receipt.insuranceExpense,
                nonCoveredExpense: receipt.nonCoveredExpense,
                totalPayment: receipt.totalPayment,
                pharmacyName: receipt.pharmacyName,
                hospitalName: receipt.hospitalName
            })),
            Pills: result.Instructions.map(instruction => ({
                pillID: instruction.Pill.pillID,
                pillName: instruction.Pill.pillName,
                pillImage: instruction.Pill.pillImage,
                pillDescription: instruction.Pill.pillDescription,
                pillType: instruction.Pill.pillType,
                storageMethod: instruction.Pill.storageMethod,
                medicineEffect: instruction.Pill.medicineEffect,
                doseTime: instruction.Pill.doseTime,
                instruction: instruction.instruction // 필요하다면 추가
            }))
        };

        res.json({ success: true, prescription: formattedResult, message: '처방 조회 성공' });
    } catch (error) {
        console.error(error);
        res.json({ success: false, prescription: [], message: '처방 조회 실패', details: error.message });
    }
});



module.exports = router;
