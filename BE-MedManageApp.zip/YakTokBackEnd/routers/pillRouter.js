const express = require('express');
const { Pill, Prescription, Receipt, Instruction } = require('../models/index');
const router = express.Router();
const { Sequelize } = require('sequelize');
const env = process.env.NODE_ENV || 'development';
const config = require('../config/config.json')[env];
const sequelize = new Sequelize(
    config.database,
    config.username,
    config.password,
    config
);
const upload = require('./uploadImage');
const isAuth = require('./authorization');

// 이미지 업로드 경로
router.post('/', upload.single('photo'));

// 약 및 관련 정보 추가 경로
router.post('/', isAuth, async (req, res) => {
    let transaction;
    try {
        transaction = await sequelize.transaction();

        const { pill: bulkPill, prescriptionID: initialPrescriptionID, 
            hospitalName, 
            prescriptionDate, 
            totalPillExpense,
            nonCoveredExpense,
            cardPayment,
            personalExpense, 
            cashPayment,
            totalPayment,
            receiptNumber,
            pharmacyName,
            insuranceExpense } = req.body;

        const userID = req.userID;

        if (!userID || !hospitalName || !prescriptionDate) {
            return res.status(400).json({ success: false, pills: [], message: '필수 정보가 누락되었습니다.' });
        }

        let prescriptionID = initialPrescriptionID;
        if (!prescriptionID) {
            const newPrescription = await Prescription.create({
                userID,
                hospitalName,
                prescriptionDate,
            }, { transaction });
            prescriptionID = newPrescription.prescriptionID;
        }

        let receipt = await Receipt.findOne({ where: { prescriptionID } });
        if (!receipt) {
            receipt = await Receipt.create({
                prescriptionID,
                userID,
                totalPillExpense,
                nonCoveredExpense,
                cardPayment,
                cashPayment,
                totalPayment,
                receiptNumber,
                personalExpense,
                insuranceExpense,
                prescriptionDate,
                pharmacyName,
                hospitalName,
            }, { transaction });
        }

        if (!Array.isArray(bulkPill)) {
            bulkPill = bulkPill ? [bulkPill] : [];
        }

        const uniqueNames = new Set();
        const duplicates = bulkPill.filter(pill => !uniqueNames.has(pill.pillName) && !uniqueNames.add(pill.pillName));
        if (duplicates.length > 0) {
            return res.status(400).json({ success: false, pills: [], message: '중복된 약 이름이 있습니다.' });
        }

        const pillResults = await Pill.bulkCreate(bulkPill.map(pill => ({
            ...pill,
            userID,
            prescriptionID,
        })), { transaction });

        const instructions = await Instruction.bulkCreate(pillResults.map(pill => ({
            prescriptionID,
            pillID: pill.pillID,
            instruction: pill.instruction || ''
        })), { transaction });

        const formattedPillResults = await Promise.all(pillResults.map(async (pill) => {
            const instruction = await Instruction.findOne({ where: { prescriptionID, pillID: pill.pillID } });
            return {
                ...pill.toJSON(),
                instruction: instruction ? instruction.instruction : ''
            };
        }));

        await transaction.commit();
        res.json({ success: true, pills: formattedPillResults, prescriptionID, message: '약 추가 성공' });
    } catch (error) {
        if (transaction) await transaction.rollback();
        console.error("트랜잭션 처리 실패: ", error);
        res.status(500).json({ success: false, pills: [], message: error.message });
    }
});

// 특정 시간대(아침, 점심, 저녁)의 약 목록 조회 경로
router.get('/:doseTime', isAuth, async (req, res) => {
    const { doseTime } = req.params;
    const userID = req.userID;

    if (!doseTime) {
        return res.status(400).json({ success: false, pills: [], message: 'doseTime이 필요합니다.' });
    }

    try {
        const pills = await Pill.findAll({
            where: { userID, doseTime },
            attributes: [
                'pillID', 'pillName', 'pillImage', 'pillDescription', 'pillType', 
                'storageMethod', 'medicineEffect', 'prescriptionID', 'doseTime'
            ],
            include: [
                {
                    model: Instruction,
                    attributes: ['instruction']
                }
            ]
        });

        if (!pills || pills.length === 0) {
            return res.status(404).json({ success: false, pills: [], message: '약 정보를 찾을 수 없습니다.' });
        }

        const formattedPills = pills.map(pill => ({
            pillID: pill.pillID,
            pillName: pill.pillName,
            pillImage: pill.pillImage,
            pillDescription: pill.pillDescription,
            pillType: pill.pillType,
            storageMethod: pill.storageMethod,
            medicineEffect: pill.medicineEffect,
            prescriptionID: pill.prescriptionID,
            doseTime: pill.doseTime,
            instruction: pill.Instruction ? pill.Instruction.instruction : ''
        }));

        res.status(200).json({ success: true, pills: formattedPills, message: '약 정보 조회 성공' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, pills: [], message: '약 정보 조회 실패', details: error.message });
    }
});



// 특정 약 정보를 수정하는 경로
router.patch('/:pillID', isAuth, async (req, res) => {
    const { pillID } = req.params;
    const updateData = req.body;
    const userID = req.userID;

    if (!pillID) {
        return res.status(400).json({ success: false, pills: [], message: 'pillID가 필요합니다.' });
    }

    try {
        const pill = await Pill.findOne({ where: { pillID, userID } });

        if (!pill) {
            return res.status(404).json({ success: false, pills: [], message: '약 정보를 찾을 수 없습니다.' });
        }

        await pill.update(updateData);
        res.status(200).json({ success: true, pills: [pill], message: '약 정보 수정 성공' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, pills: [], message: '약 정보 수정 실패', details: error.message });
    }
});







module.exports = router;
