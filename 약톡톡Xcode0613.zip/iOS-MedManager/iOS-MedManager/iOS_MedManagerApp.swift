//
//  iOS_MedManagerApp.swift
//  iOS-MedManager
//
//  Created by 한범석 on 6/3/24.
//

import SwiftUI

@main
struct iOS_MedManagerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
