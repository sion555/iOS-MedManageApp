//
//  MedicineAPIModel.swift
//  iOS-MedManager
//
//  Created by 한범석 on 6/4/24.
//

import Foundation

