//
//  InstructionView.swift
//  iOS-MedManager
//
//  Created by 한범석 on 6/13/24.
//

import SwiftUI

struct InstructionView: View {
    @Binding var isPresented: Bool
    
    var body: some View {
        VStack {
            Text("약 봉투를 바르게 찍어주세요!")
                .font(.title)
                .padding()
            
            Button("확인") {
                isPresented = false
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
    }
}

#Preview {
    InstructionView(isPresented: .constant(true))
}

