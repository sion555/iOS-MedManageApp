//
//  ConfirmationView.swift
//  iOS-MedManager
//
//  Created by 한범석 on 6/13/24.
//

import SwiftUI

struct ConfirmationView: View {
    let pillName: String
    let pillType: String
    let instruction: String

    var body: some View {
        VStack {
            Text("인식된 정보가 맞는지 확인해주세요!")
                .font(.title2)
                .padding()

            Text("약 이름: \(pillName)")
                .padding()

            Text("약 타입: \(pillType)")
                .padding()

            Text("복약 지침: \(instruction)")
                .padding()

            Button("확인") {
                // 완료 버튼 동작
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
    }
}


//#Preview {
//    ConfirmationView()
//}
