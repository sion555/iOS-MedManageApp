//
//  ProgressView.swift
//  iOS-MedManager
//
//  Created by 한범석 on 6/13/24.
//

import SwiftUI

struct LoadingView: View {
    var body: some View {
        VStack {
            ProgressView("이미지 분석 중...")
                .progressViewStyle(CircularProgressViewStyle())
                .padding()
        }
    }
}


#Preview {
    LoadingView()
}
