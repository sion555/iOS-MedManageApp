//
//  ImageReviewView.swift
//  iOS-MedManager
//
//  Created by 한범석 on 6/13/24.
//

import SwiftUI

struct ImageReviewView: View {
    @Binding var image: UIImage?
    @Binding var isPresented: Bool
    @Binding var isUploading: Bool

    var onRetake: () -> Void
    var onSubmit: () -> Void

    var body: some View {
        VStack {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 300)
                    .padding()

                HStack {
                    Button("다시 찍기") {
                        onRetake()
                    }
                    .padding()
                    .background(Color.gray)
                    .foregroundColor(.white)
                    .cornerRadius(10)

                    Button("전송") {
                        onSubmit()
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
            } else {
                Text("이미지가 없습니다.")
            }
        }
        .padding()
    }
}


//#Preview {
//    ImageReviewView()
//}
